﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LoginModule;

namespace DataAccess
{
    class BollywoodVideoDataAccess
    {
        public IEnumerable<BollywoodVideo> BollywoodVideos
        { get; set; }
    }
}
