﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LoginModule.Models;
using System.Data.Entity.Validation;
using System.Data.Entity.ModelConfiguration;

namespace LoginModule.Controllers
{
    public class BollywoodVideoController : Controller
    {
        //
        // GET: /Bollywood_Video/

        public ActionResult Index()
        {
            try
            {
                BollywoodVideoContext bollywoodVideoContext = new BollywoodVideoContext();
                List<BollywoodVideo> bol_videos = bollywoodVideoContext.BollywoodVideos.ToList();
                return View(bol_videos);
            }
            catch (ModelValidationException ex)
            {
                // Retrieve the error messages as a list of strings.
                var errorMessages = ex.InnerException;

                // Join the list to a single string.
                var fullErrorMessage = string.Join("; ", errorMessages);

                // Combine the original exception message with the new one.
                var exceptionMessage = string.Concat(ex.Message, " The validation errors are: ", fullErrorMessage);
            return View();
            }
        }

        public ActionResult VideoByMovie(string movieName)
        {
            BollywoodVideoContext bollywoodVideoContext = new BollywoodVideoContext();
            List<BollywoodVideo> bollywood_videos = bollywoodVideoContext.BollywoodVideos.ToList();
            var list = new List<BollywoodVideo>();
            foreach (var video in bollywood_videos)
            {
                if(video.movie_name==movieName)
                list.Add(new BollywoodVideo() 
                {
                    movie_name=video.movie_name,
                    video_id=video.video_id,
                    file_format=video.file_format,
                    size_in_kb=video.size_in_kb,
                    video_name=video.video_name,
                    created_on=video.created_on
                }
                    );
            }
            return View(list);
        }
        public ActionResult Details(int id)
        {
            BollywoodVideoContext bollywoodVideoContext = new BollywoodVideoContext();

            BollywoodVideo bol_video = bollywoodVideoContext.BollywoodVideos.Single(video=>video.video_id==id);
            return View(bol_video);
        }

        [HttpGet]
        [ActionName("Create")]
        public ActionResult Create_Get()
        {
            return View();
        }

        [HttpPost]
        [ActionName("Create")]
        public ActionResult Create_Post(BollywoodVideo video)
        {
            if (ModelState.IsValid)
            {
 
            }
            return View();
        }
    }
}
