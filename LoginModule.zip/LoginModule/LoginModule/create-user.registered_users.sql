﻿CREATE SCHEMA [user]
CREATE TABLE [user].[registered_users]
(
	[id] INT NOT NULL IDENTITY ,
	[username] NVARCHAR(50) NOT NULL,
	[password] NVARCHAR(MAX) NOT NULL,
	[registration_date] DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
	[email] NVARCHAR(50) NOT NULL,
	PRIMARY KEY ([id])
)

INSERT INTO [user].[registered_users]
	([username], [password], [email])
VALUES
	('test', 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3', 'test@test.test')

SELECT * from [user].[registered_users]