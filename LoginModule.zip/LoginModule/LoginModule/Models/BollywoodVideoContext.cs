﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace LoginModule.Models
{
    public class BollywoodVideoContext : DbContext
    {
        public DbSet<BollywoodVideo> BollywoodVideos { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
  {
    modelBuilder.Entity<BollywoodVideo>().ToTable("bollywood_videos", schemaName: "video");
    base.OnModelCreating(modelBuilder);
  }
    }


}