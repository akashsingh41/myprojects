﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace LoginModule.Models
{
    [Table("bollywood_videos")]
    public class BollywoodVideo
    {
        [Key]
        public int video_id { get; set; }
        public string movie_name { get; set; }
        public string video_name { get; set; }
        public int size_in_kb { get; set; }
        public DateTime created_on { get; set; }
        public string file_format { get; set; }
    }
}