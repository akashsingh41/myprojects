﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace BusinessLayer
{
    public class AudioSong
    {
        [Key]
        public int song_id { get; set; }
        [Display(Name = "Song Name")]
        public string song_name { get; set; }
        [Display(Name = "Album Name")]
        public string album_name { get; set; }
        [Display(Name = "Language")]
        public string language { get; set; }
        [Display(Name = "File Path")]
        public string file_path { get; set; }
    }
}
