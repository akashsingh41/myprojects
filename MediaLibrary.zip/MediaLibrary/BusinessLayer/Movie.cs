﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace BusinessLayer
{
    public class Movie
    {
        [Key]
        public int movie_id { get; set; }
        [Display(Name = "Movie Title")]
        public string movie_name { get; set; }
        [Display(Name = "Released Year")]
        public int release_year { get; set; }
        [Display(Name = "Language")]
        public string language { get; set; }
        [Display(Name = "File Path")]
        public string file_path { get; set; }
        [Display(Name = "Final Version")]
        public string final_version { get; set; }
    }
}
