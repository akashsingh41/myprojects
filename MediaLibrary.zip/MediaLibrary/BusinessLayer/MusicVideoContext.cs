﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayer;
using System.Data;
using System.Configuration;

namespace BusinessLayer
{
    public class MusicVideoContext
    {
        public MusicVideoDataAccess musicVideoDAL = new MusicVideoDataAccess();
        public List<MusicVideo> musicVideos
        {
            get
            {
                List<MusicVideo> listMusicVideo = new List<MusicVideo>();
                foreach (DataRow dataRow in musicVideoDAL.ListVideos().Tables[0].Rows)
                {
                    listMusicVideo.Add(
                        new MusicVideo
                        {
                            video_id = Convert.ToInt32(dataRow["video_id"]),
                            video_name = Convert.ToString(dataRow["video_name"]),
                            album_name = Convert.ToString(dataRow["album_name"]),
                            size_in_kb = Convert.ToInt32(dataRow["size_in_kb"]),
                            file_format = Convert.ToString(dataRow["file_format"]),
                            created_on = Convert.ToDateTime(dataRow["created_on"]),
                            language = Convert.ToString(dataRow["language"]),
                            file_path = Convert.ToString(dataRow["file_path"]),
                            final_version = Convert.ToString(dataRow["final_version"])
                        });
                }
                return listMusicVideo;
            }
        }

        public void UpdateMusicVideo(MusicVideo video)
        {
            List<Object> spParameters = new List<Object>();
            spParameters.Add(video.video_id);
            spParameters.Add(video.video_name);
            spParameters.Add(video.album_name);
            spParameters.Add(video.size_in_kb);
            spParameters.Add(video.created_on);
            spParameters.Add(video.file_format);
            spParameters.Add(video.language);
            spParameters.Add(video.file_path);
            spParameters.Add(video.final_version);
            String updateStoredProcedure = ConfigurationManager.AppSettings["updateMusicVideoStoredProcedure"].ToString();
            musicVideoDAL.DatabaseOperation(updateStoredProcedure,spParameters);
        }

        public void AddMusicVideo(MusicVideo video)
        {
            List<Object> spParameters = new List<Object>();
            spParameters.Add(video.video_id);
            spParameters.Add(video.video_name);
            spParameters.Add(video.album_name);
            spParameters.Add(video.size_in_kb);
            spParameters.Add(video.created_on);
            spParameters.Add(video.file_format);
            spParameters.Add(video.language);
            spParameters.Add(video.file_path);
            spParameters.Add(video.final_version);
            String createStoredProcedure = ConfigurationManager.AppSettings["createMusicVideoStoredProcedure"].ToString();
            musicVideoDAL.DatabaseOperation(createStoredProcedure, spParameters);
        }

        public void DeleteMusicVideo(MusicVideo video)
        {
            List<Object> spParameters = new List<Object>();
            spParameters.Add(video.video_id);
            String deleteStoredProcedure = ConfigurationManager.AppSettings["deleteMusicVideoStoredProcedure"].ToString();
            musicVideoDAL.DatabaseOperation(deleteStoredProcedure, spParameters);
        }
    }
}
