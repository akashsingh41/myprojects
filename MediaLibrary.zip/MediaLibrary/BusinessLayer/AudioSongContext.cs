﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayer;
using System.Data;
using System.Configuration;

namespace BusinessLayer
{
    public class AudioSongContext
    {
        public AudioSongDataAccess audioSongDAL = new AudioSongDataAccess();
        public List<AudioSong> audioSongsList
        {
            get
            {
                List<AudioSong> listAudioSong = new List<AudioSong>();
                foreach (DataRow dataRow in audioSongDAL.ListAudioSong().Tables[0].Rows)
                {
                    listAudioSong.Add(
                        new AudioSong
                        {
                            song_id = Convert.ToInt32(dataRow["song_id"]),
                            song_name = Convert.ToString(dataRow["song_name"]),
                            album_name = Convert.ToString(dataRow["album_name"]),
                            language = Convert.ToString(dataRow["language"]),
                            file_path = Convert.ToString(dataRow["file_path"]),
                        });
                }
                return listAudioSong;
            }
        }

        public void UpdateAudioSong(AudioSong audioSong)
        {
            List<Object> spParameters = new List<Object>();
            spParameters.Add(audioSong.song_id);
            spParameters.Add(audioSong.song_name);
            spParameters.Add(audioSong.album_name);
            spParameters.Add(audioSong.language);
            spParameters.Add(audioSong.file_path);
            String updateStoredProcedure = ConfigurationManager.AppSettings["updateAudioSongStoredProcedure"].ToString();
            audioSongDAL.DatabaseOperation(updateStoredProcedure, spParameters);
        }

        public void AddAudioSong(AudioSong audioSong)
        {
            List<Object> spParameters = new List<Object>();
            spParameters.Add(audioSong.song_id);
            spParameters.Add(audioSong.song_name);
            spParameters.Add(audioSong.album_name);
            spParameters.Add(audioSong.language);
            spParameters.Add(audioSong.file_path);
            String createStoredProcedure = ConfigurationManager.AppSettings["createAudioSongStoredProcedure"].ToString();
            audioSongDAL.DatabaseOperation(createStoredProcedure, spParameters);
        }

        public void DeleteAudioSong(AudioSong audioSong)
        {
            List<Object> spParameters = new List<Object>();
            spParameters.Add(audioSong.song_id);
            String deleteStoredProcedure = ConfigurationManager.AppSettings["deleteAudioSongStoredProcedure"].ToString();
            audioSongDAL.DatabaseOperation(deleteStoredProcedure, spParameters);
        }
    }
}
