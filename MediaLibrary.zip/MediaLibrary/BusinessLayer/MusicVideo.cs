﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;

namespace BusinessLayer
{
    public class MusicVideo
    {
        [Key] 
        public int video_id { get; set; }
        [Display(Name = "Album")]
        public string album_name { get; set; }
        [Display(Name = "Video Name")]
        public string video_name { get; set; }
        [Display(Name = "Size")]
        public int size_in_kb { get; set; }
        [Display(Name = "Created On")]
        public DateTime created_on { get; set; }
        [Display(Name = "Format")]
        public string file_format { get; set; }
        [Display(Name = "Language")]
        public string language { get; set; }
        [Display(Name = "File Path")]
        public string file_path { get; set; }
        [Display(Name = "Final Version")]
        public string final_version { get; set; }
    }
}
