﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayer;
using System.Data;
using System.Configuration;

namespace BusinessLayer
{
    public class MovieContext
    {
        public MovieDataAccess moviesDAL = new MovieDataAccess();
        public List<Movie> moviesList
        {
            get
            {
                List<Movie> listMovies = new List<Movie>();
                foreach (DataRow dataRow in moviesDAL.ListMovies().Tables[0].Rows)
                {
                    listMovies.Add(
                        new Movie
                        {
                            movie_id = Convert.ToInt32(dataRow["movie_id"]),
                            movie_name = Convert.ToString(dataRow["movie_name"]),
                            release_year = Convert.ToInt32(dataRow["release_year"]),
                            language = Convert.ToString(dataRow["language"]),
                            file_path = Convert.ToString(dataRow["file_path"]),
                            final_version = Convert.ToString(dataRow["final_version"])
                        });
                }
                return listMovies;
            }
        }

        public void UpdateMovie(Movie movie)
        {
            List<Object> spParameters = new List<Object>();
            spParameters.Add(movie.movie_id);
            spParameters.Add(movie.movie_name);
            spParameters.Add(movie.release_year);
            spParameters.Add(movie.language);
            spParameters.Add(movie.file_path);
            spParameters.Add(movie.final_version);
            String updateStoredProcedure = ConfigurationManager.AppSettings["updateMovieStoredProcedure"].ToString();
            moviesDAL.DatabaseOperation(updateStoredProcedure, spParameters);
        }

        public void AddMovie(Movie movie)
        {
            List<Object> spParameters = new List<Object>();
            spParameters.Add(movie.movie_id);
            spParameters.Add(movie.movie_name);
            spParameters.Add(movie.release_year);
            spParameters.Add(movie.language);
            spParameters.Add(movie.file_path);
            spParameters.Add(movie.final_version);
            String createStoredProcedure = ConfigurationManager.AppSettings["createMovieStoredProcedure"].ToString();
            moviesDAL.DatabaseOperation(createStoredProcedure, spParameters);
        }

        public void DeleteMovie(Movie movie)
        {
            List<Object> spParameters = new List<Object>();
            spParameters.Add(movie.movie_id);
            String deleteStoredProcedure = ConfigurationManager.AppSettings["deleteMovieStoredProcedure"].ToString();
            moviesDAL.DatabaseOperation(deleteStoredProcedure, spParameters);
        }
    }
}
