﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Data;
using System.Configuration;


namespace DataAccessLayer
{
    public class MusicVideoDataAccess
    {
        public SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["mediaConnection"].ToString());
        public DataSet ListVideos()
        {
            DataSet listVideos = new DataSet();
            SqlCommand sqlCommand = new SqlCommand(ConfigurationManager.AppSettings["fetchMusicVideosStoredProcedure"].ToString(), sqlCon);
            sqlCommand.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter sqlAdapter = new SqlDataAdapter(sqlCommand);
            sqlAdapter.Fill(listVideos);
            return listVideos;
        }

        public void DatabaseOperation(String storedProcedureName, List<Object> spParameters)
        {
            sqlCon.Open();
            SqlCommand sqlCommand = new SqlCommand(storedProcedureName, sqlCon);

                if(!storedProcedureName.Contains("uspDeleteMusicVideo"))
                {
                    sqlCommand.Parameters.AddWithValue("@VIDEO_ID", spParameters[0]);
                    sqlCommand.Parameters.AddWithValue("@VIDEO_NAME", spParameters[1] == null ? DBNull.Value : spParameters[1]);
                    sqlCommand.Parameters.AddWithValue("@MOVIE_NAME", spParameters[2] == null ? DBNull.Value : spParameters[2]);
                    sqlCommand.Parameters.AddWithValue("@SIZE_IN_KB", spParameters[3] == null ? DBNull.Value : spParameters[3]);
                    sqlCommand.Parameters.AddWithValue("@CREATED_ON", spParameters[4] == null ? DBNull.Value : spParameters[4]);
                    sqlCommand.Parameters.AddWithValue("@FILE_FORMAT", spParameters[5] == null ? DBNull.Value : spParameters[5]);
                    sqlCommand.Parameters.AddWithValue("@LANGUAGE", spParameters[6] == null ? DBNull.Value : spParameters[6]);
                    sqlCommand.Parameters.AddWithValue("@FILE_PATH", spParameters[7] == null ? DBNull.Value : spParameters[7]);
                    sqlCommand.Parameters.AddWithValue("@FINAL_VERSION", spParameters[8] == null ? DBNull.Value : spParameters[8]);
                }
                else
                {
                    sqlCommand.Parameters.AddWithValue("@VIDEO_ID", spParameters[0]);
                }
            
                sqlCommand.CommandType = CommandType.StoredProcedure;
                int noOfAffectedRows = sqlCommand.ExecuteNonQuery();
                System.Diagnostics.Trace.Write(String.Format("{0} rows affected  by {1}", noOfAffectedRows.ToString(), storedProcedureName));
                sqlCon.Close();
        }
    }
}
