﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Data;
using System.Configuration;


namespace DataAccessLayer
{
    public class MovieDataAccess
    {
        public SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["mediaConnection"].ToString());
        public DataSet ListMovies()
        {
            DataSet listMovies = new DataSet();
            SqlCommand sqlCommand = new SqlCommand(ConfigurationManager.AppSettings["fetchMoviesStoredProcedure"].ToString(), sqlCon);
            sqlCommand.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter sqlAdapter = new SqlDataAdapter(sqlCommand);
            sqlAdapter.Fill(listMovies);
            return listMovies;
        }

        public void DatabaseOperation(String storedProcedureName, List<Object> spParameters)
        {
            sqlCon.Open();
            SqlCommand sqlCommand = new SqlCommand(storedProcedureName, sqlCon);

            if (!storedProcedureName.Contains("uspDeleteMovie"))
            {
                sqlCommand.Parameters.AddWithValue("@MOVIE_ID", spParameters[0]);
                sqlCommand.Parameters.AddWithValue("@MOVIE_NAME", spParameters[1] == null ? DBNull.Value : spParameters[1]);
                sqlCommand.Parameters.AddWithValue("@RELEASE_YEAR", spParameters[2] == null ? DBNull.Value : spParameters[2]);
                sqlCommand.Parameters.AddWithValue("@FILE_FORMAT", spParameters[3] == null ? DBNull.Value : spParameters[3]);
                sqlCommand.Parameters.AddWithValue("@LANGUAGE", spParameters[4] == null ? DBNull.Value : spParameters[4]);
                sqlCommand.Parameters.AddWithValue("@FILE_PATH", spParameters[5] == null ? DBNull.Value : spParameters[5]);
                sqlCommand.Parameters.AddWithValue("@FINAL_VERSION", spParameters[6] == null ? DBNull.Value : spParameters[6]);
            }
            else
            {
                sqlCommand.Parameters.AddWithValue("@MOVIE_ID", spParameters[0]);
            }

            sqlCommand.CommandType = CommandType.StoredProcedure;
            int noOfAffectedRows = sqlCommand.ExecuteNonQuery();
            System.Diagnostics.Trace.Write(String.Format("{0} rows affected  by {1}", noOfAffectedRows.ToString(), storedProcedureName));
            sqlCon.Close();
        }
    }
}
