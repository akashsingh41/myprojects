﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Data;
using System.Configuration;


namespace DataAccessLayer
{
    public class AudioSongDataAccess
    {
        public SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["mediaConnection"].ToString());
        public DataSet ListAudioSong()
        {
            DataSet listAudioSong = new DataSet();
            SqlCommand sqlCommand = new SqlCommand(ConfigurationManager.AppSettings["fetchAudioSongsStoredProcedure"].ToString(), sqlCon);
            sqlCommand.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter sqlAdapter = new SqlDataAdapter(sqlCommand);
            sqlAdapter.Fill(listAudioSong);
            return listAudioSong;
        }

        public void DatabaseOperation(String storedProcedureName, List<Object> spParameters)
        {
            sqlCon.Open();
            SqlCommand sqlCommand = new SqlCommand(storedProcedureName, sqlCon);

            if (!storedProcedureName.Contains("uspDeleteAudioSong"))
            {
                sqlCommand.Parameters.AddWithValue("@SONG_ID", spParameters[0]);
                sqlCommand.Parameters.AddWithValue("@SONG_NAME", spParameters[1] == null ? DBNull.Value : spParameters[1]);
                sqlCommand.Parameters.AddWithValue("@ALBUM_NAME", spParameters[2] == null ? DBNull.Value : spParameters[2]);
                sqlCommand.Parameters.AddWithValue("@LANGUAGE", spParameters[4] == null ? DBNull.Value : spParameters[4]);
                sqlCommand.Parameters.AddWithValue("@FILE_PATH", spParameters[5] == null ? DBNull.Value : spParameters[5]);
            }
            else
            {
                sqlCommand.Parameters.AddWithValue("@SONG_ID", spParameters[0]);
            }

            sqlCommand.CommandType = CommandType.StoredProcedure;
            int noOfAffectedRows = sqlCommand.ExecuteNonQuery();
            System.Diagnostics.Trace.Write(String.Format("{0} rows affected  by {1}", noOfAffectedRows.ToString(), storedProcedureName));
            sqlCon.Close();
        }
    }
}
