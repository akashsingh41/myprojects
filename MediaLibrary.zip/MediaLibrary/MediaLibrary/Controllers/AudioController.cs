﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BusinessLayer;
using PagedList;
using PagedList.Mvc;

namespace MediaLibrary.Controllers
{
    public class AudioController : Controller
    {
        //
        // GET: /Audio/

        public ActionResult Index(int? page)
        {
            AudioSongContext audioSongContext = new AudioSongContext();
            List<AudioSong> audioSongList = audioSongContext.audioSongsList;
            return View(audioSongList.ToPagedList(page ?? 1, 20));
        }

        public ActionResult Details(int id)
        {
            AudioSongContext audioSongContext = new AudioSongContext();
            AudioSong audioSong = audioSongContext.audioSongsList.Single(x => x.song_id == id);
            return View(audioSong);
        }

        [HttpGet]
        [ActionName("Edit")]
        public ActionResult Edit(int id)
        {
            AudioSongContext audioSongContext = new AudioSongContext();
            AudioSong audioSong = audioSongContext.audioSongsList.Single(x => x.song_id == id);
            return View(audioSong);
        }

        [HttpPost]
        [ActionName("Edit")]
        public ActionResult Edit(AudioSong audioSong)
        {
            if (ModelState.IsValid)
            {
                AudioSongContext audioSongContext = new AudioSongContext();
                audioSongContext.UpdateAudioSong(audioSong);

            }
            return RedirectToAction("Index");
        }

        [HttpGet]
        [ActionName("Create")]
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ActionName("Create")]
        public ActionResult Create(AudioSong audioSong)
        {
            if (ModelState.IsValid)
            {
                AudioSongContext audioSongContext = new AudioSongContext();
                audioSongContext.AddAudioSong(audioSong);
            }
            return RedirectToAction("Index");
        }

        [ActionName("Delete")]
        public ActionResult Delete(AudioSong audioSong)
        {
            AudioSongContext audioSongContext = new AudioSongContext();
            audioSongContext.DeleteAudioSong(audioSong);
            return RedirectToAction("Index");
        }

    }
}
