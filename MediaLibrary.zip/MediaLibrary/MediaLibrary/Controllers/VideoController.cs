﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BusinessLayer;
using PagedList;
using PagedList.Mvc;

namespace MediaLibrary.Controllers
{
    public class VideoController : Controller
    {
        //
        // GET: /Video/
        
        public ActionResult Index(int? page)
        {
            MusicVideoContext videoContext = new MusicVideoContext();
            List<MusicVideo> musicVideoList = videoContext.musicVideos;
            return View(musicVideoList.ToPagedList(page ??1,20));
        }

        public ActionResult Details(int id)
        {
            MusicVideoContext videoContext = new MusicVideoContext();
            MusicVideo video = videoContext.musicVideos.Single(x => x.video_id==id);
            return View(video);
        }

        [HttpGet]
        [ActionName("Edit")]
        public ActionResult Edit(int id)
        {
            MusicVideoContext videoContext = new MusicVideoContext();
            MusicVideo musicVideo = videoContext.musicVideos.Single(video => video.video_id == id);
            return View(musicVideo);
        }

        [HttpPost]
        [ActionName("Edit")]
        public ActionResult Edit(MusicVideo musicVideo)
        {
            if (ModelState.IsValid)
            {
                MusicVideoContext videoContext = new MusicVideoContext();
                videoContext.UpdateMusicVideo(musicVideo);
 
            }
            return RedirectToAction("Index");
        }

        [HttpGet]
        [ActionName("Create")]
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ActionName("Create")]
        public ActionResult Create(MusicVideo musicVideo)
        {
            if (ModelState.IsValid)
            {
                MusicVideoContext videoContext = new MusicVideoContext();
                videoContext.AddMusicVideo(musicVideo);
            }
            return RedirectToAction("Index");
        }

        [ActionName("Delete")]
        public ActionResult Delete(MusicVideo musicVideo)
        {
            MusicVideoContext videoContext = new MusicVideoContext();
            videoContext.DeleteMusicVideo(musicVideo);
            return RedirectToAction("Index");
        }

    }
}
