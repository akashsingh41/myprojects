﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BusinessLayer;
using PagedList;
using PagedList.Mvc;

namespace MediaLibrary.Controllers
{
    public class MovieController : Controller
    {
        //
        // GET: /Movie/

        public ActionResult Index(int? page)
        {
            MovieContext movieContext = new MovieContext();
            List<Movie> movieList = movieContext.moviesList;
            return View(movieList.ToPagedList(page ?? 1, 20));
        }

        public ActionResult Details(int id)
        {
            MovieContext movieContext = new MovieContext();
            Movie movie = movieContext.moviesList.Single(x => x.movie_id == id);
            return View(movie);
        }
        [HttpGet]
        [ActionName("Edit")]
        public ActionResult Edit(int id)
        {
            MovieContext movieContext = new MovieContext();
            Movie movie = movieContext.moviesList.Single(x => x.movie_id == id);
            return View(movie);
        }

        [HttpPost]
        [ActionName("Edit")]
        public ActionResult Edit(Movie movie)
        {
            if (ModelState.IsValid)
            {
                MovieContext movieContext = new MovieContext();
                movieContext.UpdateMovie(movie);

            }
            return RedirectToAction("Index");
        }

        [HttpGet]
        [ActionName("Create")]
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ActionName("Create")]
        public ActionResult Create(Movie movie)
        {
            if (ModelState.IsValid)
            {
                MovieContext movieContext = new MovieContext();
                movieContext.AddMovie(movie);
            }
            return RedirectToAction("Index");
        }

        [ActionName("Delete")]
        public ActionResult Delete(Movie movie)
        {
            MovieContext movieContext = new MovieContext();
            movieContext.DeleteMovie(movie);
            return RedirectToAction("Index");
        }

    }
}
