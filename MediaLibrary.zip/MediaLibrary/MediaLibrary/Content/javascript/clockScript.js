﻿
setInterval(showDateTime, 1000);

function showDateTime()
{
    var dateTimetxt = new Date();
    document.getElementById("localTimer").innerText = dateTimetxt;
}